import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dept-dialog',
  templateUrl: './dept-dialog.component.html',
  styleUrls: ['./dept-dialog.component.scss']
})
export class DeptDialogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
