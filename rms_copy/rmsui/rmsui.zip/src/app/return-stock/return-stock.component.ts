import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-return-stock',
  templateUrl: './return-stock.component.html',
  styleUrls: ['./return-stock.component.scss']
})
export class ReturnStockComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
