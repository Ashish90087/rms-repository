export const environment = {
  production: true,
  rootUrl: 'http://localhost:3000/'
  //rootUrl: '/'
};
